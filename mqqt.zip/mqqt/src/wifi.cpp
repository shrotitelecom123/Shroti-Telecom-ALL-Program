/*
  -----------------------
  ElegantOTA - Async Demo Example
  -----------------------

  NOTE: Make sure you have enabled Async Mode in ElegantOTA before compiling this example!
  Guide: https://docs.elegantota.pro/async-mode/

  Skill Level: Beginner

  This example provides with a bare minimal app with ElegantOTA functionality which works
  with AsyncWebServer.

  Github: https://github.com/ayushsharma82/ElegantOTA
  WiKi: https://docs.elegantota.pro

  Works with both ESP8266 & ESP32

  -------------------------------

  Upgrade to ElegantOTA Pro: https://elegantota.pro

*/

#include <WiFi.h>
#include <WiFiAP.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <ElegantOTA.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <WebSerial.h>
#include "esp_log.h"
#include "FS.h"
#include <LittleFS.h>
#include "tpms.h"

#define FORMAT_LITTLEFS_IF_FAILED true

char ssid[17];
char pass[20];
bool ACCESSPOINT=0;



AsyncWebServer server(80);
Preferences preferences;
void otaServer();
void webServer();

const char* PARAM_INPUT_1 = "pass";
const char* passPath = "/pass.txt";

unsigned long ota_progress_millis = 0;
// Set LED GPIO
const int ledPin = 2;
// Stores LED state
String ledState;


// Replaces placeholder with LED state value
String processor(const String& var){
  SER.println(var);
  if(var == "TPORTVALUE") return String(TPMS_PORT_MASK);
  else if(var == "IPORTVALUE") return String(IAMS_PORT_MASK);
  else if(var == "HPORTVALUE") return String(HOOTER_MASK);
  else if(var == "TBKVALUE") return String(TPMS_REPT_BLK_MASK);
  else if(var == "SYSCONFIG") 
      return "{"+String(UPDATE_INTERVAL)+","+String(BLOCK_INTERVAL)+","+String(HOOTER_INTERVAL)+"}";
  else if(var == "SSID") return String(imei);
  else return String();
}

void onOTAStart() {
  // Log when OTA has started
  SER.println("OTA update started!");
  // <Add your own code here>
}

void onOTAProgress(size_t current, size_t final) {
  // Log every 1 second
  if (millis() - ota_progress_millis > 1000) {
    ota_progress_millis = millis();
    SER.printf("OTA Progress Current: %u bytes, Final: %u bytes", current, final);
  }
}

void onOTAEnd(bool success) {
  // Log when OTA has finished
  if (success) {
    SER.println("OTA update finished successfully!");
  } else {
    SER.println("There was an error during OTA update!");
  }
  // <Add your own code here>
}

bool wifiActivate(void) {

  IPAddress AP_LOCAL_IP(192, 168, 1, 1);
  IPAddress AP_GATEWAY_IP(192, 168, 1, 254);
  IPAddress AP_NETWORK_MASK(255, 255, 255, 0);
  if(ACCESSPOINT){
    WiFi.softAPConfig(AP_LOCAL_IP, AP_GATEWAY_IP, AP_NETWORK_MASK);
    WiFi.softAPsetHostname("TPMS_SERVER");
    if (!WiFi.softAP(ssid, pass))
    {
        SER.println("AP Creation Failed");
        while (1);
    }
    SER.println("AP Created Successfully");
    return true;  
  }else{
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, pass);
    // Wait for connection
    while (WiFi.status() != WL_CONNECTED) {
      delay(500);
      SER.printf(".");
    }
    IPAddress IP =WiFi.localIP();
    SER.printf("Connected to: %s Having IP address: %d:%d:%d:%d\n",ssid,IP.operator[](0),IP.operator[](1),IP.operator[](2),IP.operator[](3));
    return true;
  }
}
void wifiInit(){
  preferences.begin("wifi", true);
  if(~preferences.isKey("type")){
    preferences.end();
    preferences.begin("wifi", false);
    preferences.putBool("type",1);
    preferences.putString("ssid","D2SM_2G_2");
    preferences.putString("pass","sanjay1234");
    preferences.end();
    preferences.begin("wifi", true);
  }
  ACCESSPOINT=preferences.getBool("type",1);

  if(ACCESSPOINT)  sprintf(ssid,"%s",imei);
  else sprintf(ssid,"%s",preferences.getString("ssid"));  
  sprintf(pass,"%s",preferences.getString("pass"));
  preferences.end();
/*
  preferences.begin("wifi", false);
  preferences.putString("pass","sanjay1234");
  sprintf(pass,"%s",preferences.getString("pass"));
  preferences.end();
*/
  if(wifiActivate()) {
    //server.setTimeout(60000);  // Example: Set timeout to 60 seconds

      // Route for root / web page
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(LittleFS, "/index.html", "text/html", false, processor);
    });

    // Route to load style.css file
    server.on("/style.css", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(LittleFS, "/style.css", "text/css");
    });
    
    //server.serveStatic("/", LittleFS, "/");

    // Route to set TPMS Port
    server.on("/tport", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(LittleFS, "/tport.html", "text/html", false, processor);
    });

    server.on("/", HTTP_POST, [](AsyncWebServerRequest *request){
      if (request->hasParam("sysconf", true)){
        UPDATE_INTERVAL=atoi(request->getParam("updateinterval", true)->value().c_str());
        BLOCK_INTERVAL=atoi(request->getParam("blockinterval", true)->value().c_str());
        HOOTER_INTERVAL=atoi(request->getParam("hooterinterval", true)->value().c_str());   
        SER.printf("Received Values are : UPINT :%d, BLOCK INT : %d, Hoot Int : %d",UPDATE_INTERVAL,
        BLOCK_INTERVAL,HOOTER_INTERVAL); 
        saveParam();  
      }
      else if (request->hasParam("newPassword", true)){
        preferences.begin("wifi", false);
        if(request->hasParam("ssid_option", true)){
          SER.printf("SSID OPTION :%s\n",request->getParam("ssid_option", true)->value().c_str());
          if(request->getParam("ssid_option", true)->value() =="accespoint") {
          //preferences.putBool("type",1);
            
          }else {
            //preferences.putBool("type",0);
            if(request->hasParam("ssid", true)) {
              SER.printf("SSID:%s\n",request->getParam("ssid", true)->value().c_str());
              sprintf(ssid,"%s",request->getParam("ssid", true)->value().c_str());
              preferences.putString("ssid",request->getParam("ssid", true)->value().c_str());
            }
          }
        }
        SER.printf("PASS :%s\n",request->getParam("newPassword", true)->value().c_str());
        preferences.putString("pass",request->getParam("newPassword", true)->value().c_str());
        preferences.end();      
      }
      else{
        char port[10];
        uint16_t value=0;
        for (int i=0; i<16;i++){
          sprintf(port,"port%d",i);
          if (request->hasParam(port, true)) {
            if(atoi(request->getParam(port, true)->value().c_str())) value |= (1<<(i-1));
          } 
        }
        if (request->hasParam("tport", true))TPMS_PORT_MASK=value;
        else if (request->hasParam("iport", true))IAMS_PORT_MASK=value;
        else if (request->hasParam("hport", true))HOOTER_MASK=value;
        else if (request->hasParam("tbkport", true))TPMS_REPT_BLK_MASK=value;
        if(value)SER.printf("Received Value is : %u",value);  
        saveParam();
      }      
      request->send(LittleFS, "/response.html", "text/html", false, processor);          
    });



    // Route to set TPMS Port Blocking
    server.on("/tbkport", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, HIGH);    
      request->send(LittleFS, "/tbkport.html", "text/html", false, processor);
    });

    // Route to set IAMS Port
    server.on("/iport", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, HIGH);    
      request->send(LittleFS, "/iport.html", "text/html", false, processor);
    });

    // Route to set Hooter Enable for port
    server.on("/hoot", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, HIGH);    
      request->send(LittleFS, "/hoot.html", "text/html", false, processor);
    });

    // Route to set System Configuration
    server.on("/sysconfig", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, HIGH);    
      request->send(LittleFS, "/sysconfig.html", "text/html", false, processor);
    });

    // Route to set TPMS Port
    server.on("/wifimgr", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, HIGH);    
      request->send(LittleFS, "/wifimgr.html", "text/html", false, processor);
    });

    // Route to set GPIO to HIGH
    server.on("/on", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, HIGH);    
      request->send(LittleFS, "/index.html", "text/html", false, processor);
    });
    
    // Route to set GPIO to LOW
    server.on("/off", HTTP_GET, [](AsyncWebServerRequest *request){
      digitalWrite(ledPin, LOW);    
      request->send(LittleFS, "/index.html", "text/html", false, processor);
    });
  

    ElegantOTA.begin(&server);    // Start ElegantOTA
    // ElegantOTA callbacks
    ElegantOTA.onStart(onOTAStart);
    ElegantOTA.onProgress(onOTAProgress);
    ElegantOTA.onEnd(onOTAEnd);

     // Initialize WebSerial
    WebSerial.begin(&server);

    // Attach a callback function to handle incoming messages
    WebSerial.onMessage([](uint8_t *data, size_t len) {
      Serial.printf("Received %lu bytes from WebSerial: ", len);
      Serial.write(data, len);
      Serial.println();
      WebSerial.println("Received Data...");
      String d = "";
      for(size_t i = 0; i < len; i++){
        d += char(data[i]);
      }
      WebSerial.println(d);
    });


    server.begin();
    SER.println("HTTP server started");

  }
  ElegantOTA.loop();
}

/*
void webServer(){
  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/index.html", String(), false, processor);
  });
  
  // Route to load style.css file
  server.on("/style.css", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/style.css", "text/css");
  });

  // Route to set GPIO to HIGH
  server.on("/on", HTTP_GET, [](AsyncWebServerRequest *request){
    digitalWrite(ledPin, HIGH);    
    request->send(SPIFFS, "/index.html", String(), false, processor);
  });
  
  // Route to set GPIO to LOW
  server.on("/off", HTTP_GET, [](AsyncWebServerRequest *request){
    digitalWrite(ledPin, LOW);    
    request->send(SPIFFS, "/index.html", String(), false, processor);
  });
}
*/
