// Adapted from: https://github.com/espressif/arduino-esp32/blob/master/libraries/LittleFS/examples/LITTLEFS_test/LITTLEFS_test.ino
// Project details: https://RandomNerdTutorials.com/esp32-write-data-littlefs-arduino/

#include <Arduino.h>
#include "FS.h"
#include <LittleFS.h>
#include "tpms.h"

//  You only need to format LittleFS the first time you run a
//  test or else use the LITTLEFS plugin to create a partition 
//  https://github.com/lorol/arduino-esp32littlefs-plugin

#define FORMAT_LITTLEFS_IF_FAILED true

void listDir(char * dirname, uint8_t levels){
    SER.printf("Listing directory: %s\r\n", dirname);
    println((char*)dirname);
    File root = LittleFS.open(dirname);
    if(!root){
        SER.println("- failed to open directory");
        return;
    }
    if(!root.isDirectory()){
        SER.println(" - not a directory");
        return;
    }

    File file = root.openNextFile();
    while(file){
        if(file.isDirectory()){
            SER.print("  DIR : ");
            SER.println(file.name());
            if(levels){
                listDir(file.path(), levels -1);
            }
        } else {
            SER.print(file.name());
            SER.print("\tSIZE: ");
            SER.println(file.size());
        }
        file = root.openNextFile();
    }
}

void createDir(const char * path){
    SER.printf("Creating Dir: %s\n", path);
    if(LittleFS.mkdir(path)){
        SER.println("Dir created");
    } else {
        SER.println("mkdir failed");
    }
}

void removeDir(const char * path){
    SER.printf("Removing Dir: %s\n", path);
    if(LittleFS.rmdir(path)){
        SER.println("Dir removed");
    } else {
        SER.println("rmdir failed");
    }
}

String readFile(const char * path){
    SER.printf("Reading file: %s\r\n", path);
    File file = LittleFS.open(path);
    if(!file || file.isDirectory()){
        SER.println("- failed to open file for reading");
        return String();
    }
    String fileContent;
    SER.println("- read from file:");
    while(file.available()){
        fileContent=file.readString();
    }
    SER.printf("%s\n",fileContent.c_str());
    file.close();
    return fileContent;
}

String readFileLine(const char * path, int line){
    SER.printf("Reading file: %s\r\n", path);
    File file = LittleFS.open(path);
    if(!file || file.isDirectory()){
        SER.println("- failed to open file for reading");
        return String();
    }
    String fileContent;
    SER.println("- read from file:");
    while(file.available()){
        for(int i=0;i<line;i++)file.readStringUntil('\n');
        fileContent = file.readStringUntil('\n');
        break;
    }
    file.close();    
    return fileContent;
}

void writeFile(const char * path, const char * message){
    SER.printf("Writing file: %s\r\n", path);
    File file = LittleFS.open(path, FILE_WRITE);
    if(!file){
        SER.println("- failed to open file for writing");
        return;
    }
    if(file.print(message)){
        SER.println("- file written");
    } else {
        SER.println("- write failed");
    }
    SER.println(message);
    file.close();
}

uint8_t appendFile(const char * path, const char * message){
    SER.printf("Appending to file: %s\r\n", path);
    uint8_t status;
    File file = LittleFS.open(path, FILE_APPEND);
    if(!file){
        SER.println("- failed to open file for appending");
        return 0;
    }
    if(file.print(message)){
        SER.println("- message appended");
        status=1;
    } else {
        SER.println("- append failed");
        status=0;
    }
    SER.println(message);
    file.close();
    return status;
}

void renameFile(const char * path1, const char * path2){
    SER.printf("Renaming file %s to %s\r\n", path1, path2);
    if (LittleFS.rename(path1, path2)) {
        SER.println("- file renamed");
    } else {
        SER.println("- rename failed");
    }
}

void deleteFile(const char * path){
    SER.printf("Deleting file: %s\r\n", path);
    if(LittleFS.remove(path)){
        SER.println("- file deleted");
    } else {
        SER.println("- delete failed");
    }
}

void testFileIO(const char * path){
    SER.printf("Testing file I/O with %s\r\n", path);
    static uint8_t buf[512];
    size_t len = 0;
    File file = LittleFS.open(path, FILE_WRITE);
    if(!file){
        SER.println("- failed to open file for writing");
        return;
    }

    size_t i;
    SER.print("- writing" );
    uint32_t start = millis();
    for(i=0; i<2048; i++){
        if ((i & 0x001F) == 0x001F){
          SER.print(".");
        }
        file.write(buf, 512);
    }
    SER.println("");
    uint32_t end = millis() - start;
    SER.printf(" - %u bytes written in %u ms\r\n", 2048 * 512, end);
    file.close();

    file = LittleFS.open(path);
    start = millis();
    end = start;
    i = 0;
    if(file && !file.isDirectory()){
        len = file.size();
        size_t flen = len;
        start = millis();
        SER.print("- reading" );
        while(len){
            size_t toRead = len;
            if(toRead > 512){
                toRead = 512;
            }
            file.read(buf, toRead);
            if ((i++ & 0x001F) == 0x001F){
              SER.print(".");
            }
            len -= toRead;
        }
        SER.println("");
        end = millis() - start;
        SER.printf("- %u bytes read in %u ms\r\n", flen, end);
        file.close();
    } else {
        SER.println("- failed to open file for reading");
    }
}

void fileInit(){
    if(!LittleFS.begin(FORMAT_LITTLEFS_IF_FAILED)){
        SER.println("LittleFS Mount Failed");
        return;
    }
/*
    createDir(LittleFS, "/mydir"); // Create a mydir folder
    writeFile(LittleFS, "/mydir/hello1.txt", "Hello1"); // Create a hello1.txt file with the content "Hello1"
    listDir(LittleFS, "/", 1); // List the directories up to one level beginning at the root directory
    deleteFile(LittleFS, "/mydir/hello1.txt"); //delete the previously created file
    removeDir(LittleFS, "/mydir"); //delete the previously created folder
    listDir(LittleFS, "/", 1); // list all directories to make sure they were deleted
    
    writeFile(LittleFS, "/hello.txt", "Hello "); //Create and write a new file in the root directory
    appendFile(LittleFS, "/hello.txt", "World!\r\n"); //Append some text to the previous file
    readFile(LittleFS, "/hello.txt"); // Read the complete file
    renameFile(LittleFS, "/hello.txt", "/foo.txt"); //Rename the previous file
    readFile(LittleFS, "/foo.txt"); //Read the file with the new name
    deleteFile(LittleFS, "/foo.txt"); //Delete the file
    testFileIO(LittleFS, "/test.txt"); //Testin
    deleteFile(LittleFS, "/test.txt"); //Delete the file
  
    Serial.println( "Test complete" ); 
*/
}

