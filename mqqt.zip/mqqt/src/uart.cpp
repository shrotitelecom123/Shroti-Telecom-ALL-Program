#include <Arduino.h>
#include <stdio.h>  
#include "string.h"
#include "esp_system.h"
#include "esp_log.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

#include "driver/uart.h"
#include "driver/gpio.h"

#include "tpms.h"


#define TXD_PIN (GPIO_NUM_33)                               //++ UART TX and RX Pins for Communication
#define RXD_PIN (GPIO_NUM_32)
#define GSM_EN (GPIO_NUM_10)                                          //++ Set any GPIO to connect to Simcomm ENABLE Pin
#define UART_RX_BUFFER_MASK ( RX_BUF_SIZE - 1)


char gsm_buff[RX_BUF_SIZE];                                        //++ String to store gsm received data
static volatile unsigned char UART_RxHead=0;
static volatile unsigned char UART_RxTail=0;
static volatile unsigned char UART_RxBuf[RX_BUF_SIZE];
extern uint8_t failedCount;
bool recd_subsription = false; 
SemaphoreHandle_t xSemaMqqtRx = NULL;
SemaphoreHandle_t xSemaMqqtTx = NULL;
char mqtt_rx_buff[MQTT_RX_BUF_SIZE];                               


int gsmSend(const char *data)                  //++ Sending AT Commands to Simcomm via UART
{   
    if(xSemaphoreTake(xSemaMqqtTx, portMAX_DELAY)){
        const int len = strlen(data);
        char sendData[100];
        for(int i=0; i<len-1; i++)sendData[i]=data[i];
        const int txBytes = uart_write_bytes(UART_NUM_1, data, len);
        SER.printf("Wrote %d bytes: %s\r\n", txBytes, data );
        vTaskDelay(500 / portTICK_PERIOD_MS);     
        xSemaphoreGive(xSemaMqqtTx); 
        return txBytes;   
    }
    return 0;    
}

void gsmBuffStore(const char * data){
    clearBuff(gsm_buff);
    for(int i=0;i<strlen(data);i++){
        gsm_buff[i]=data[i];
    }
}


void gsmRx(int cumulative) // store received data in gsm_buff
{
	int i=0,j=0;
    unsigned char tmptail=(UART_RxTail + 1) & UART_RX_BUFFER_MASK;
	if (cumulative) i = strlen(gsm_buff); 
	else {
		i=0;
		memset(gsm_buff,0,sizeof(gsm_buff));
	}
	while (UART_RxHead != UART_RxTail)
	{
		gsm_buff[i] = UART_RxBuf[tmptail];
        UART_RxTail=tmptail;
        tmptail++;
		if((gsm_buff[i]!=0xD)&&(gsm_buff[i]!=0xA)) i++;
        if(i>=(RX_BUF_SIZE-2)){
            for(int j=0; j<RX_BUF_SIZE/2;j++ ){
                gsm_buff[j]=gsm_buff[j+RX_BUF_SIZE/2];
                gsm_buff[j+RX_BUF_SIZE/2]=0;
            }
        }
		if(i>=RX_BUF_SIZE) break;
	}
    if (!(cumulative)) if(strcasestr(gsm_buff,"ERROR")) failedCount++;
}

uint8_t gsmValidRx(const char * parameter, int duration)
{
	int i=0,j=0;
	gsmRx(0);
	while(i<duration)
	{
		vTaskDelay(100 / portTICK_PERIOD_MS);
		gsmRx(1);
		i++;
		if(strcasestr(gsm_buff,parameter)) break;
        if(strcasestr(gsm_buff,"ERROR")) {
            failedCount++;
            return 0;
        }
	}
	vTaskDelay(500 / portTICK_PERIOD_MS);
	gsmRx(1);
	if(strcasestr(gsm_buff,parameter)) return(1);
	else return(0);
}


static void rx_task(void *arg)                                              //++ UART Receive Task 
{
    SER.printf("(rx_task)-Job is Running on Core :%d\n", xPortGetCoreID());
    //static const char *RX_TASK_TAG = "RX_TASK";
    //esp_log_level_set(RX_TASK_TAG, ESP_LOG_INFO);
    uint8_t *data = (uint8_t *)malloc(RX_BUF_SIZE + 1);
    while (1)
    {
        const int rxBytes = uart_read_bytes(UART_NUM_1, data, RX_BUF_SIZE, 300 / portTICK_RATE_MS);

        if (rxBytes > 0)
        {
            data[rxBytes] = 0;  
            SER.printf("Read %d bytes: %s\n", rxBytes, data);
            if(strcasestr((char *) data,"+QMTRECV:")) {
                SER.println("Mqtt subscription msg received"); 
                memset(mqtt_rx_buff,0,sizeof(mqtt_rx_buff));
                for (int i=0;i<rxBytes;i++){
                    if(data[i]=='{' ){
                        for(int k=0;k<rxBytes-i;k++){
                            mqtt_rx_buff[k]=data[i+k];
                            if (mqtt_rx_buff[k]=='}') break;                      
                        }
                    }
                }
                xSemaphoreGive(xSemaMqqtRx);
            }
            for(int i=0; i< rxBytes; i++){
                unsigned char tmphead = ( UART_RxHead + 1) & UART_RX_BUFFER_MASK;
            
                if ( tmphead == UART_RxTail ) {
                    SER.println("Receive Buffer Overflow"); 
                    gsmRx(0);
                }else{
                    UART_RxBuf[tmphead] = data[i];
                    UART_RxHead = tmphead;                    
                }
            }
        }
        vTaskDelay(500 / portTICK_PERIOD_MS);
    }
    free(data);
}

void gsmPower(uint8_t status){
    if(status==1){
        PWR_4G_OFF;
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        PWR_4G_ON;
        vTaskDelay(2100 / portTICK_PERIOD_MS);
        PWR_4G_OFF;
        vTaskDelay(3500 / portTICK_PERIOD_MS);
    }
    if(status==0){
        PWR_4G_OFF;
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        PWR_4G_ON;
        vTaskDelay(3100 / portTICK_PERIOD_MS);
        PWR_4G_OFF;
        for(int i=0;i<33;i++)vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
    if(status==2){
        PWR_4G_OFF;
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        PWR_4G_ON;
        vTaskDelay(3100 / portTICK_PERIOD_MS);
        PWR_4G_OFF;
        for(int i=0;i<30;i++)vTaskDelay(1000 / portTICK_PERIOD_MS);
        PWR_4G_OFF;
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        PWR_4G_ON;
        vTaskDelay(2100 / portTICK_PERIOD_MS);
        PWR_4G_OFF;
        vTaskDelay(3500 / portTICK_PERIOD_MS);
    }
}

void uartInit(void)                                        //++ Initializing UART
{
    SER.printf("(uartInit)-Job is Running on Core :%d\n", xPortGetCoreID());
    //GSM Enable 
    gsmPower(1);    


    //UART Initialization for GSM Modem
    const uart_config_t uart_config = 
    {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };

    xSemaMqqtRx = xSemaphoreCreateBinary();

    xSemaMqqtTx = xSemaphoreCreateMutex();
    assert(xSemaMqqtTx);
    if ((xSemaMqqtTx) != NULL) xSemaphoreGive((xSemaMqqtTx));

    // We won't use a buffer for sending data.
    uart_driver_install(UART_NUM_1, RX_BUF_SIZE * 2, 0, 0, NULL, 0);
    uart_param_config(UART_NUM_1, &uart_config);
    uart_set_pin(UART_NUM_1, TXD_PIN, RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    xTaskCreate(rx_task, "gsm_rx_task", 2048 * 2, NULL, configMAX_PRIORITIES-5, NULL);               //++ Create FreeRtos Tasks
    
    for(int i=0;i<20;i++) {
        SER.printf("Waiting for Response---%d\n",i);
        gsmSend("AT\r");   // Transmit AT check modem
        if(gsmValidRx("OK",10)) {
            SER.println("GSM Module Powered ON");
            vTaskDelay(1000 / portTICK_PERIOD_MS);
            break;
        }
        if(i==5)modemReset();
    }

    
    
    
}







