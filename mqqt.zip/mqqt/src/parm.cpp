#include <Arduino.h>
#include <ArduinoJson.h>
#include "tpms.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

uint16_t TPMS_PORT_MASK=0xFFFF;
uint16_t TPMS_REPT_BLK_MASK=0xFFFF;
uint16_t HOOTER_MASK=0xFFFF;
uint16_t IAMS_PORT_MASK=0xFFFF;
uint8_t UPDATE_INTERVAL=60;
uint8_t BLOCK_INTERVAL=10;
uint8_t HOOTER_INTERVAL=5;

void saveParam(void){
    char param[200];
    JsonDocument doc;    
    doc["TPOMSK"] =TPMS_PORT_MASK;
    doc["TRBMSK"] =TPMS_REPT_BLK_MASK;
    doc["HMAK"]   =HOOTER_MASK;
    doc["IPOMSK"] =IAMS_PORT_MASK;
    doc["UPINT"]  =UPDATE_INTERVAL;
    doc["BKNT"]   =BLOCK_INTERVAL;
    doc["HINT"]   =HOOTER_INTERVAL;
    doc["IMEI"]   =imei;
    serializeJson(doc, param);
    writeFile("/param.txt",param);  
    
}

void readParam(void){
    String p=readFile("/param.txt");
    char param[200];
    //printf(p.c_str());
    if(p=="") saveParam();
    else{
       sprintf(param,"%s",p.c_str());
       //SER.println(param);
       JsonDocument doc;
       deserializeJson(doc,param);
       //sprintf(imei,"%s",doc["IMEI"]);
       strcpy(imei,doc["IMEI"]);
       SER.println(imei);
       TPMS_PORT_MASK      = doc["TPOMSK"];
       TPMS_REPT_BLK_MASK  = doc["TRBMSK"];
       HOOTER_MASK         = doc["HMAK"] ;
       IAMS_PORT_MASK      = doc["IPOMSK"];
       UPDATE_INTERVAL     = doc["UPINT"];
       BLOCK_INTERVAL      = doc["BKNT"];
       HOOTER_INTERVAL     = doc["HINT"] ;  
    }
}

