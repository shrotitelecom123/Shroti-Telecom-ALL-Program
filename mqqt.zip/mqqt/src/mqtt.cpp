
#include <stdio.h>  
#include "string.h"


char mqtt_publish_topic[100];                               //++ String to store MQTT Publishing Topic
uint64_t count = 0;                                         //++ Count to post on MQTT
bool mqtt_connect_flag = 0;                                 //++ Flag for MQTT Connection
bool disconnect_mqtt = false;


void mqttInit(void){
    memset(mqtt_publish_topic, 0, sizeof(mqtt_publish_topic));
    sprintf(mqtt_publish_topic, "4GBOARD_SIMCOMM");                         //++ Topic to Publish on MQTT 
}