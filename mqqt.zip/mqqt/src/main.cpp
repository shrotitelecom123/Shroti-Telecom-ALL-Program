
#include <Arduino.h>
#include "tpms.h"
#include "esp_system.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

char mac_address[20];                                       //++ Array to store Mac Address
uint8_t esp_chip_id[6];                                     //++ Array to get Chip ID
int num=0;
uint8_t look_task;

void setup() {
  int delaytime=1000;
  //WebSerial.begin(&server);
  Serial.begin(115200);
  SER.printf("(setup)-Job is Running on Core :%d\n", xPortGetCoreID());
   // Serial.setDebugOutput(true);
  // put your setup code here, to run once:
    SER.println( "Setup function started");
    delay(5000);
    fileInit();
    //defaultParm();
    readParam();
    uartInit(); 
    wifiInit();
    esp_efuse_mac_get_default(esp_chip_id);                                 //++ Get the ESP Chip ID
    sprintf(mac_address, "%02x:%02x:%02x:%02x:%02x:%02x", esp_chip_id[0], esp_chip_id[1], esp_chip_id[2], esp_chip_id[3], esp_chip_id[4], esp_chip_id[5]);
    printf("MAC Address is %s\n", mac_address);
    for(;;)vTaskDelay(1000 / portTICK_PERIOD_MS);    
    tpmsInit();
    
    while(gsmInit()){
      failedCount++;
      delay(1000);
      SER.printf("failedCount: %d\n",failedCount);
      if(failedCount > 4)checkGsm();
    }
    
    
    //void mobusInit();
    look_task=tCount("M");  
}

void loop() {
  // put your main code here, to run repeatedly:
  if(look_task!=tCount("M")){
    look_task=tCount("M");
    if(!(look_task%45))corrTime();
  
    if(!(look_task%10)){
      gsmSend("AT\r");   // Transmit AT check modem
      if(!(gsmValidRx("OK",100)))modemReset();  
    }
  }
  vTaskDelay(30000 / portTICK_PERIOD_MS);    
}



