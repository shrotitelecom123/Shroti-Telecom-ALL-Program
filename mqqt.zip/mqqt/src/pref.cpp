#include <Arduino.h>
#include "tpms.h"
#include "esp_system.h"
#include "esp_log.h"
#include <Preferences.h>

Preferences pref;




void readValue(char * partition){
    pref.begin(partition, false); 
}