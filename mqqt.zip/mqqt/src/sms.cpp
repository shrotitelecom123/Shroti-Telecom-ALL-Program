#include <Arduino.h>
#include <stdio.h>  
#include "string.h"
#include "esp_system.h"
#include "esp_log.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "tpms.h"

char sms_msg[160];
char sms_mdn[16];
extern char gsm_buff[];
extern char imei[]; 



uint8_t copy_number(char * buff, char * number)	{
	unsigned char a=0;
	unsigned char b=0;
	char temp[20]={'\0'};
	if(strlen(buff)<16) return 0;	
	while((buff[a]!='C')||(buff[a+1]!='P')||(buff[a+2]!='B')||(buff[a+3]!='R'))a++;
	while(buff[a]!='"') a++;
	a++;
	while(buff[a]!='"'){
		temp[b]=buff[a];
		a++; b++;
	}
	a=b=0;
	if(strcasestr(buff,",145,")) b=3;
	while (temp[b]>0) { number[a]=temp[b]; a++;b++;}
	return 1;
}

uint8_t copy_sms_number(char * buff, char * number){
	//+CMGR: "REC READ","+917021885300","ci","20/08/19,13:19:47+22"IMEIOK
	unsigned char a=0;
	unsigned char b=0;
	char temp[20]={'\0'};
	if(strlen(buff)<16) return 0;	
	while((buff[a]!='C')||(buff[a+1]!='M')||(buff[a+2]!='G')||(buff[a+3]!='R'))a++;
	while(buff[a]!='"') a++;  //"REC
	a++;
	while(buff[a]!='"') a++;  //READ"
	a++;
	while(buff[a]!='"') a++;
	a++;
	while(buff[a]!='"'){
		temp[b]=buff[a];
		a++; b++;
	}
	a=b=0;
	if(temp[0]=='+' && temp[1]=='9' && temp[2]=='1'   ) b=3;
	while (temp[b]>0) { number[a]=temp[b]; a++;b++;}
	return 1;
}

void store_sms_msg(char * buff, char * msg, int loc, int len){
	int i=0,j=0,k=0,c=0;
	for(i=0;i<160;i++){
		if(buff[i] == '"')
		{
			c++;
			if(c == loc)
			{
				j =i+1;
				while(buff[j+2]!='\0'&& buff[j]!='"'&& (buff[j+2]!=0xD)&&(buff[j+2]!=0xA))
				{
					msg[k] = buff[j];
					k++;
					j++;
					if(k>=len)break;
				} msg[k]='\0'; i=j;
			}
			if (c>loc) break;
		}
	}
}

void send_sms(char *mdn, char * msg){
	char esc_seq[2];
    esc_seq[0]='\x1A';
	if((strlen(mdn)>=10)&&(strlen(msg)>2))
	{
		gsmSend("ATH\r");
		gsmSend("AT\r");
		delay_ms(200);
		gsmRx(0); 
		gsmSend("AT+CMGS=\"+91");
		gsmSend(mdn);
		gsmSend("\"\r");
		gsmValidRx(">",100);
		gsmSend(msg);
		delay_ms(100);
		gsmSend(esc_seq);
		gsmValidRx("+CMGS:",100);
	}
}

uint8_t decode_sms(uint8_t i){
	uint8_t status=0;
	char dispp[30]={'\0'};
    char gsm_recd[1024]={'\0'};

    memset(sms_msg,0,sizeof(sms_msg));
    memset(sms_mdn,0,sizeof(sms_mdn));
	gsmRx(0);
	sprintf(dispp,"AT+CMGR=%d\r",i);
	gsmSend(dispp);
	gsmValidRx("OK",100);
    sprintf(gsm_recd,"%s",gsm_buff);
	if(strcasestr(gsm_recd,"+CMGR:")&&(strlen(gsm_recd)>=15))  //,"+CMGR: \"REC"
	{
		store_sms_msg(gsm_recd,sms_msg,8,158);
		copy_sms_number(gsm_recd,sms_mdn);
		sprintf(dispp,"AT+CMGD=%d\r",i);
		gsmSend(dispp);
		gsmValidRx("OK",100);
		status=1;
	}
	return(status);
}

void sms_command() {
	char request[150]={'\0'};
	uint8_t sms_len;
	sprintf(request,"%s",sms_msg);
	sms_len= (uint8_t) strlen(sms_msg);
	if(strcasestr(sms_msg,"SSTART")){
		//Start SMS Service
	}
	else if(strcasestr(sms_msg, "SSTOP")){
		//Stop SMS Services 
	}
	else if(strcasestr(sms_msg, "IMEI")){
		sprintf(sms_msg,"%s",imei);
		send_sms(sms_mdn,sms_msg);
		memset(sms_mdn,0,sizeof(sms_mdn));
	}
	else if(strcasestr(sms_msg, "SYSRESET"))sysReset();
	
	//else if(strcasestr(sms_msg, "NIGHT"))comm.TheftTime ^=1;
	
	else if(strcasestr(sms_msg, "ALARMRST")) {
		//alarm_reset_check();
	}
	else if(strcasestr(sms_msg, "VTOFFSET")) {
		//vtTimer=15;
	}
		
	else if(strcasestr(sms_msg, "START")){
		//start Hoter
		
	}	else if(strcasestr(sms_msg, "STOP"))
	{
		//Stop Hooter
		
	}
	else if(strcasestr(sms_msg,"STATUS"))
	{
		//Status Msg	
	}
	
	else if(strcasestr(sms_msg, "SIGQ")){
		//signal(); 
	}
	else if(strcasestr(sms_msg, "VER"))	{
		//smscopy(10); 
	}
	
	else{
		//smscopy(21);send_sms(sms_mdn,sms_msg);
	}
	
	if(sms_len!=strlen(sms_msg))  if(!(strcasestr(sms_msg,"Thanks!! Request is invalid"))) ;//sms_response(sms_mdn,sms_msg,request);
	
}

void check_sms(void){
	uint8_t i;
	for(i=1;i<10;i++){
		if(decode_sms(i)){
			sms_command();    
			memset(sms_msg,0,sizeof(sms_msg));
            memset(sms_mdn,0,sizeof(sms_mdn));
		}
	}
}





