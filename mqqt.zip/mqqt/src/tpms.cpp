
#include <Arduino.h>
#include <ArduinoJson.h>
#include <stdio.h>  
#include "esp_system.h"
#include "string.h"
#include "tpms.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "driver/gpio.h"

#define ICNUMBER 2
#define TINPIN (GPIO_NUM_27)  
#define SERPIN 	(GPIO_NUM_5) 
#define RCLKPIN (GPIO_NUM_26) 
#define SRCLKPIN (GPIO_NUM_25)
#define COVER_OPEN (GPIO_NUM_34)
#define VBAT_DETECT_ADC 36
#define VIN_DETECT_ADC 39

#define S0PIN_ON l74hc595_setregon(4);
#define S1PIN_ON l74hc595_setregon(5);
#define S2PIN_ON l74hc595_setregon(6);
#define S3PIN_ON l74hc595_setregon(7);

#define S0PIN_OFF l74hc595_setregoff(4);
#define S1PIN_OFF l74hc595_setregoff(5);
#define S2PIN_OFF l74hc595_setregoff(6);
#define S3PIN_OFF l74hc595_setregoff(7);

SemaphoreHandle_t xSemaMqqtTxBuff = NULL;
extern SemaphoreHandle_t xSemaMqqtRx;
extern char mqtt_rx_buff[];
uint16_t tpms, iams, old_iams, old_tpms;
uint8_t icarray[ICNUMBER];
uint8_t recent_alarm[16]; 
uint8_t relay_time=0xFF;   

void clearBuff(char * buff){
    //for(int i=0;i<strlen(buff);i++)buff[i]=0;
    memset(buff, 0, sizeof(buff));
}

void delay_ms(int value){
    vTaskDelay(value / portTICK_PERIOD_MS);
}

void DBUG(String data){
	Serial.println(data);
	vTaskDelay(1000 / portTICK_PERIOD_MS);

}

uint8_t timeLapsed(uint8_t x){
	uint8_t y=tCount("M");
    if(x > y) return (60+y)-x;
    else return y-x;
}

static void rx_sub(void *arg){
    SER.printf("(rx_sub)-Job is Running on Core :%d", xPortGetCoreID());
    for(;;){        
        if(xSemaphoreTake(xSemaMqqtRx, portMAX_DELAY)){
            SER.println("Receeived Semphore");
            SER.printf("Mssage : %s\n",mqtt_rx_buff); 
			JsonDocument doc;   
			deserializeJson(doc,mqtt_rx_buff);			
			if(doc["type"]=="update"){
				if(doc["TPOMSK"].is<uint16_t>()) TPMS_PORT_MASK      	= doc["TPOMSK"];
				if(doc["TRBMSK"].is<uint16_t>()) TPMS_REPT_BLK_MASK  	= doc["TRBMSK"];
				if(doc["HMAK"].is<uint16_t>()) HOOTER_MASK         	= doc["HMAK"] ;
				if(doc["IPOMSK"].is<uint16_t>()) IAMS_PORT_MASK      	= doc["IPOMSK"];
				if(doc["UPINT"].is<uint8_t>()) UPDATE_INTERVAL     	= doc["UPINT"];
				if(doc["BKNT"].is<uint8_t>()) BLOCK_INTERVAL      	= doc["BKNT"];
				if(doc["HINT"].is<uint8_t>()) HOOTER_INTERVAL     	= doc["HINT"]; 
				saveParam();
			}
			else if(doc["type"]=="action"){
				//hooter on off, dg start, stop, reboot
				if(doc["HOOTER"].is<bool>()) {
					if(doc["HOOTER"]) {
						HOOTER_ON;
						SETBIT(iams,hooterStatus);
						relay_time=(uint8_t) tCount("M");
					}else {
						HOOTER_OFF;
						CLEARBIT(iams,hooterStatus);
					}
				}
				if(doc["REBOOT"].is<bool>()) {
					if(doc["REBOOT"]) {
						ESP.restart();
					}
				}
				if(doc["MODEMRST"].is<bool>()) {
					if(doc["MODEMRST"]) {
						modemReset();
					}
				}
			}
			else if (doc["type"]=="request"){
				//imei, iccid, config param, etc

			}
        }        
    }
//+CMQTTRECV:0,"znn11",16,"one message
}

void sysReset(void){
    
}

void l74hc595_shiftout() {
	uint8_t i,j;
	gpio_set_level(RCLKPIN,0); //set the register-clock pin low
	for(i = 0; i < ICNUMBER; i++){
		//iterate through the bits in each registers
		for(j = 0; j < 8; j++){
			gpio_set_level(RCLKPIN,0); //set the serial-clock pin low
			if((icarray[i] & (1 << j))>>j)gpio_set_level(SERPIN,1);
			else gpio_set_level(SERPIN,0);
			gpio_set_level(SRCLKPIN,1); //set the serial-clock pin high
			 gpio_set_level(SERPIN,0); //set the datapin low again
		}
	}
	gpio_set_level(RCLKPIN,1); //set the register-clock pin high to update the output of the shift-register
}

void l74hc595_setreg(uint16_t regindex, uint8_t val) {
	uint8_t bitindex,current;
	uint16_t byteindex;
	//get valid byteindex, first byte is for first ic attached
	byteindex = (ICNUMBER-1)-regindex/8;
	//bit address 0 is Qa
	bitindex = (uint8_t)((8-1) - regindex % 8);
	current = icarray[byteindex];

	current &= ~(uint8_t)(1 << bitindex); //clear the bit
	current |= val << bitindex; //set the bit

	icarray[byteindex] = current; //set the new value
	
	l74hc595_shiftout();
}

uint8_t l74hc4067_read(uint8_t channel) {
	if(channel & 1) {S0PIN_ON;} else S0PIN_OFF;
	if(channel & 2) {S1PIN_ON;} else S1PIN_OFF;
	if(channel & 4) {S2PIN_ON;} else S2PIN_OFF;
	if(channel & 8) {S3PIN_ON;} else S3PIN_OFF;
	vTaskDelay(100 / portTICK_PERIOD_MS);
	return gpio_get_level(TINPIN);
}

uint16_t checkTpms(){
	uint8_t curr_time= (uint8_t) tCount("M");
	for(int i=0;i<INPUT_CHANNEL;i++) {
		if((TPMS_PORT_MASK>>i)&1){ 
			if(l74hc4067_read(i)){
				if(recent_alarm[i]==0xFF){
					tpms |= (1<< i);
					recent_alarm[i]=curr_time;
				}
				else if(recent_alarm[i]==0xFE)tpms |= (1<< i);
				else ;			
			} 
			else tpms &= ~(1<< i);
		}
		else tpms &= ~(1<< i);
	}
	for(int i=0;i<16;i++) if(recent_alarm[i] < 0xFE) if (abs(curr_time-recent_alarm[i])>BLOCK_INTERVAL) recent_alarm[i]=0xFF;
	if((old_tpms^tpms)&tpms){
		HOOTER_ON;
		SETBIT(iams,hooterStatus);
		relay_time=(uint8_t) tCount("M");
	}
	if(CHECKBIT(iams,hooterStatus)){
		if(timeLapsed(relay_time)>HOOTER_INTERVAL){
			HOOTER_OFF;
			CLEARBIT(iams,hooterStatus);
		}
	}
	return(old_tpms^tpms);
}

uint16_t checkVoltage(String type){
	uint16_t volt;
	if(type=="VIN"){
		volt=analogReadMilliVolts(VIN_DETECT_ADC)*183/33;
		if (volt<2000) volt=0;
	}
	else if(type=="VBAT"){
		volt=analogReadMilliVolts(VBAT_DETECT_ADC)*183/33;
		if (volt<2000) volt=0;
	}
	else;
	return volt;
}

uint16_t checkIams(){
    if(gpio_get_level(COVER_OPEN)) SETBIT(iams,alarmCover);
    else CLEARBIT(iams,alarmDoor);

    uint16_t input_volt = checkVoltage("VIN");
    vTaskDelay(200 / portTICK_PERIOD_MS);
    uint16_t batt_volt = checkVoltage("VBAT");

    if(input_volt < 10000) SETBIT(iams,alarmInput);
    if(input_volt > 12000) CLEARBIT(iams,alarmInput);
    if(batt_volt < 10500) SETBIT(iams,alarmBattCritcal);
    if(batt_volt > 11000)  CLEARBIT(iams,alarmInput);

    iams &= IAMS_PORT_MASK;	
	
	return(old_iams^iams);
					
}

void selfCheck(void){
	uint16_t batt_volt;
	/*
	//batt_volt=getBattVolt();
	if(batt_volt <= 950) iams |= (1 << alarmBattCritcal);
	else if(batt_volt >= 1050) iams &= ~(1 << alarmBattCritcal);
	
	if(COVER_OPEN) SETBIT(iams,alarmCover);
	else CLEARBIT(iams,alarmCover);
	
	if(INPUT) iams |= (1 << alarmInput);
	else iams &= ~(1 << alarmInput);
	
	if(HOOTERONCOVEROPEN){
		if(CHECKBIT(iams,alarmCover) & (!(CHECKBIT(iams_old,alarmCover)))){
			RELAY=1;
			comm.relay=1;	
			if(comm.TheftTime) relay_count=HOOTERNIGHTTIME;
			else relay_count=HOOTERDAYTIME;
		}
	}

    */
}

static void tpms_task(void *arg){
    SER.printf("(tpms_task)-Job is Running on Core :%d\n", xPortGetCoreID());
    while(!(CHECKBIT(tpmsStatus,gsm))) vTaskDelay(2000 / portTICK_PERIOD_MS);
	if(readFile("/alarm.txt")=="") CLEARBIT(tpmsStatus,fileStatus); else SETBIT(tpmsStatus,fileStatus);
	uint8_t last_update=tCount("M");
	for(;;){		
		if(checkTpms()||checkIams())SETBIT(tpmsStatus,alarmChanged);
		if(CHECKBIT(tpmsStatus,alarmChanged)||timeLapsed(last_update) >= UPDATE_INTERVAL){
		    if(xSemaphoreTake(xSemaMqqtTxBuff, portMAX_DELAY)){				
                JsonDocument doc;
                char mqtt_tx_buff[MQTT_TX_BUF_SIZE];
                doc["imei"] = imei;
                doc["time"] = tCount("EPOCH");
                doc["tpms"] = tpms;
                doc["iams"] = iams;
				doc["vin"] 	= checkVoltage("VIN");
				doc["vbat"] = checkVoltage("VBAT");
				serializeJson(doc, mqtt_tx_buff);
				if(!(mqttPub("ALARM", mqtt_tx_buff))){
					if(CHECKBIT(tpmsStatus,alarmChanged)){
						int len =strlen(mqtt_tx_buff);
						mqtt_tx_buff[len]='\r';
						mqtt_tx_buff[len+1]='\n';
						if(CHECKBIT(tpmsStatus,fileStatus))appendFile("/alarm.txt",mqtt_tx_buff);
						else writeFile("/alarm.txt",mqtt_tx_buff);
						SETBIT(tpmsStatus,fileStatus);
					}
				}else{
					if(CHECKBIT(tpmsStatus,fileStatus)){
						memset(mqtt_tx_buff,0,sizeof(mqtt_tx_buff));
						for(int i=0; i < 1000; i++){
							sprintf(mqtt_tx_buff,"%s",readFileLine("/alarm.txt",i).c_str());
							if(strlen(mqtt_tx_buff)) mqttPub("ALARM", mqtt_tx_buff);	
							else {
								deleteFile("/alarm.txt");
								CLEARBIT(tpmsStatus,fileStatus);
								break;
							}
							vTaskDelay(2000 / portTICK_PERIOD_MS);													
						}												
					}
				}		
                //give xSemaMqqtTx                  
				old_iams=iams;
				old_tpms=tpms;
				last_update=tCount("M"); 
				CLEARBIT(tpmsStatus,alarmChanged);        
            }     
			xSemaphoreGive(xSemaMqqtTxBuff); 
        }
		vTaskDelay(30000 / portTICK_PERIOD_MS);
		
    }
}

void tpmsInit(void){
    SER.printf("(tpmsInit)-Job is Running on Core :%d\n", xPortGetCoreID());
    gpio_set_direction(TINPIN, GPIO_MODE_INPUT);
    gpio_set_direction(COVER_OPEN, GPIO_MODE_INPUT);
    gpio_set_direction(SERPIN, GPIO_MODE_OUTPUT);
    gpio_set_direction(RCLKPIN, GPIO_MODE_OUTPUT);
    gpio_set_direction(SRCLKPIN, GPIO_MODE_OUTPUT);
    analogReadResolution(12);

    xSemaMqqtTxBuff = xSemaphoreCreateMutex();
    assert(xSemaMqqtTxBuff);
    if ((xSemaMqqtTxBuff) != NULL) xSemaphoreGive((xSemaMqqtTxBuff));

	for(int i=0;i<16;i++){
		if((TPMS_REPT_BLK_MASK>>i)&1)recent_alarm[i]=0xFF;
		else recent_alarm[i]=0xFE;
	}
	checkTpms();
	checkIams();		
	old_iams=iams;
	old_tpms=tpms;
    SER.println("TPMS INIT TASK to be start");
    xTaskCreate(rx_sub, "mqtt_sub", 3072, NULL, configMAX_PRIORITIES-6, NULL);
    SER.println("TPMS INIT TASK started");
	xTaskCreate(tpms_task, "tpms_task", 2048*2, NULL, configMAX_PRIORITIES-10, NULL);

}

void l74hc595_setchipbyte(uint8_t chipindex, uint8_t val) {
	icarray[ICNUMBER-1-chipindex] = val; //set the new value
}

void l74hc595_setregalloff() {
	uint16_t i;
	for(i = 0; i < ICNUMBER*8; i++){
		l74hc595_setreg(i, 0);
	}
}

void l74hc595_setregallon() {
	uint16_t i;
	for(i = 0; i < ICNUMBER*8; i++){
		l74hc595_setreg(i, 1);
	}
}

