#include <Arduino.h>
#include <stdio.h>  
#include "string.h"
#include "esp_system.h"
#include "esp_log.h"

#include "nvs.h"
#include "nvs_flash.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/uart.h"
#include "driver/gpio.h"

#include "math.h"
#include "time.h"
#include "tpms.h"

#include <ESP32Time.h>


ESP32Time rtc(3600*5.5);

int signal_strength = 0;                                    //++ Varible to Store Signal Strength
uint8_t esp_restart_count = 0;                              //++ Counter Condition to restart ESP32
char imei[17];                                              //++ IMEI of the modem
uint8_t failedCount=0;
uint8_t sms_count=1;
extern char gsm_buff[];                                         //++ String to store gsm received data
uint8_t msg_id=1;
uint16_t tpmsStatus=0;

uint8_t testAt(void){
    gsmSend("AT\r");   // Transmit AT check modem
	delay_ms(2000);
	gsmSend("ATE0\r");   // Transmit AT check modem
	delay_ms(2000);
	gsmSend("AT\r");   // Transmit AT check modem
	delay_ms(2000);
 	if(gsmValidRx("OK",20)) return 1;
	else return 0;
}

uint8_t getImei(void){
	gsmRx(0);
    SER.println(imei);
    if(strlen(imei)<15){
        memset(imei, 0, sizeof(imei));
        gsmSend("AT+GSN\r");   // Transmit AT check modem
        vTaskDelay(400 / portTICK_PERIOD_MS);
        gsmRx(0);
        char * p =strstr(gsm_buff,"8");
        if(p){
            int i=0;
            //p+=4;			
            while(*p!='O') {
                imei[i]=*p;
                i++; p++;
            }
            for(i=0;i<15;i++){
                if(!(isdigit(imei[i])))return 0;
            }
        }
        if(strlen(imei) == 15) {
            saveParam();
            SER.println(imei);
            return 1;
        }
	    else return 0;        
    }
    //SER.println(imei);
    return 1;	
}

uint8_t setApn(void){
	char apn[50]={'\0'};
    gsmSend("AT+CFUN=1\r");   // Transmit AT check modem
	gsmValidRx("OK",150);	
	gsmRx(0);
	gsmSend("AT+COPS?\r");
	gsmValidRx("+COPS:",20);	
	if(strcasestr(gsm_buff,"airtel")) sprintf(apn,"airteliot.com"); //sprintf(apn,"airteliot.com");
	else if (strcasestr(gsm_buff,"JIO")) sprintf(apn,"Jionet");
	else if (strcasestr(gsm_buff,"Vi India")) sprintf(apn,"www");
	else if (strcasestr(gsm_buff,"bsnl")) sprintf(apn,"shrotibsnl");
	else if (strcasestr(gsm_buff,"smart")) sprintf(apn,"internet");
	else if (strcasestr(gsm_buff,"globe")) sprintf(apn,"internet.globe.com.ph");
	else  sprintf(apn,"Jionet");

	gsmRx(0);
	//Configuring APN
    char data[100];
    sprintf(data,"AT+CGDCONT=1,\"IPV4V6\",\"%s\"\r",apn);
	gsmSend(data);
	gsmValidRx("OK",10);
	return 1;
	
}

uint8_t signal(void){
	uint8_t sigstrength =0;	
	gsmSend("AT\r");
	gsmRx(0);
	gsmSend("AT+CSQ\r");    // READ THE PH NUMBER FROM LOC2
	gsmValidRx("+CSQ:",50);
	gsmRx(1);						// STORE IN MYDATA2
	
	for(int i=0;i<160;i++){
		if(gsm_buff[i] == '+'){
			if(gsm_buff[i+1] == 'C'){
				if(gsm_buff[i+2] == 'S'){
					if(gsm_buff[i+3] == 'Q'){
						if(gsm_buff[i+4] == ':'){
							int j=i+6;
							if(gsm_buff[j+1] != ','){
								sigstrength=(gsm_buff[j]-'0')*10+(gsm_buff[j+1]-'0');
							}
							else sigstrength=(gsm_buff[j]-'0'); //k=j+2;
						}
						break;
					}
				}
			}
		}
	}
	if (sigstrength==99) sigstrength=120;
	else sigstrength = 113-2*sigstrength;
	return sigstrength;
}

void syncTime(void) {
	gsmSend("AT\r");
	gsmRx(0);
	//gsmSend("AT+QNTP=\"asia.pool.ntp.org\",22\r\n");    // READ THE PH NUMBER FROM LOC2
	//gsmValidRx("OK",50);
    gsmSend("AT+CCLK?\r\n");    // READ THE PH NUMBER FROM LOC2
    if (gsmValidRx("CCLK:",50)){
        SER.println("Successfully Time Updated");
        gsmRx(1);
        for (int i = 0; i <= strlen(gsm_buff); i++)
        {
            if (gsm_buff[i] == 'C' && gsm_buff[i + 1] == 'C' && gsm_buff[i + 2] == 'L' && gsm_buff[i + 3] == 'K' && gsm_buff[i + 4] == ':')
            {               //+CCLK: "14/01/01,02:14:36+08"
                char timeval[6][5];
                int index_of_data = i + 7;
                int index_of_time_str = 0;
                timeval[0][0]='2';
                timeval[0][1]='0';
                timeval[0][2]=gsm_buff[i+7];
                timeval[0][3]=gsm_buff[i+8];

                timeval[1][0]=gsm_buff[i+10];
                timeval[1][1]=gsm_buff[i+11];

                timeval[2][0]=gsm_buff[i+13];
                timeval[2][1]=gsm_buff[i+14];

                timeval[3][0]=gsm_buff[i+16];
                timeval[3][1]=gsm_buff[i+17];

                timeval[4][0]=gsm_buff[i+19];
                timeval[4][1]=gsm_buff[i+20];

                timeval[5][0]=gsm_buff[i+22];
                timeval[5][1]=gsm_buff[i+23];

                rtc.setTime(atoi(timeval[5]), atoi(timeval[4]), atoi(timeval[3]), atoi(timeval[2]), atoi(timeval[1]), atoi(timeval[0]));  // 17th Jan 2021 15:24:30

            }
        }
        SER.printf("Time Set To : %s\n",rtc.getDateTime());
    }
    SER.println("Failed to Connect Time Server");	
}

uint32_t tCount (const char * level){
    if(!strcmp(level,"MS")) return rtc.getMinute()*60+rtc.getSecond();
    else if(!strcmp(level,"HM")) return rtc.getHour()*3600+rtc.getMinute()*60;
    else if(!strcmp(level,"H")) return rtc.getHour();
    else if(!strcmp(level,"M")) return rtc.getMinute();
    else if(!strcmp(level,"S")) return rtc.getSecond();
    else if(!strcmp(level,"EPOCH")) return rtc.getEpoch()-19800;
    else return 0;
}

void corrTime(void){
    uint32_t hh=tCount("H");
    if(!(hh%4)){
        if(CHECKBIT(tpmsStatus,timeSync)) return;
        syncTime();
        SETBIT(tpmsStatus,timeSync);
    }else
        if(CHECKBIT(tpmsStatus,timeSync)) CLEARBIT(tpmsStatus,timeSync);
}

void modemReset(void){
    if(!(testAt())) {
        RST_4G_ON;
        vTaskDelay(300 / portTICK_PERIOD_MS);
        RST_4G_OFF;
        while(!(testAt())) vTaskDelay(2000 / portTICK_PERIOD_MS);
        gsmInit();
    }
    else{
        gsmSend("AT+CRESET\r\n");
        gsmRx(0);
        while(!(testAt())) vTaskDelay(2000 / portTICK_PERIOD_MS);
        gsmInit();
    }    
}

void mqttClose(void){
    gsmSend("AT+QMTDISC=0\r\n");
    gsmValidRx("+QMTDISC: 0,0",20);
    gsmSend("AT+QMTCLOSE=0\r\n");
    gsmValidRx("+QMTCLOSE: 0,0",15);
       
}

uint8_t mqttStart(void){
    char data[100];
    //char topic[100];
    memset(data,0,sizeof(data));

    gsmSend("AT+QPING=1,\"www.google.com\"\r");
    gsmValidRx("+QPING:",20);
    if(!(strcasestr(gsm_buff,"+QPING: 0"))){
        gsmRx(0);
        gsmSend("AT+QIACT?\r");   
        gsmValidRx("OK",10);
        if(!(strcasestr(gsm_buff,"+QIACT:"))){
            gsmRx(0);
            gsmSend("AT+QIDEACT=1\r");
            gsmValidRx("OK",10);
            gsmRx(0);	
            gsmSend("AT+QIACT=1\r");
            gsmValidRx("OK",100);
            gsmRx(0);
            gsmSend("AT+QIACT?\r");   
            gsmValidRx("OK",10);	
            if(!(strcasestr(gsm_buff,"+QIACT:"))) return 0;
        }	
    }

    gsmSend("AT+QMTCFG=\"session\",0,0\r\n");       //AT+QMTCFG="session",<client_idx>[,<clean_session>]
    gsmValidRx("OK",10);

    gsmSend("AT+QMTCFG=\"recv/mode\",0,0,1\r\n");       //AT+QMTCFG="recv/mode",<client_idx>[,<msg_recv_mode>[,<msg_len_enable>]]
    gsmValidRx("OK",10);

    memset(data,0,sizeof(data));
    sprintf(data,"AT+QMTCFG=\"will\",0,1,1,0,\"%sWILL\",\"%s\"\r\n",MQTT_TOPIC,imei);
    gsmSend(data);       //"will",<client_idx>[,<will_fg>[,<will_qos>,<will_retain>,<willtopic>,<willmessage>]]
    gsmValidRx("OK",10);

    memset(data,0,sizeof(data));
    sprintf(data,"AT+QMTOPEN=0,\"%s\",%d\r\n",MQTT_SERVER,MQTT_PORT);
    gsmSend(data); //AT+QMTOPEN=<client_idx>,<host_name>,<port>
    gsmValidRx("+QMTOPEN: 0,0",20);

    memset(data,0,sizeof(data));
    sprintf(data,"AT+QMTCONN=0,\"%s\"\r\n",imei);
    gsmSend(data);
    if(gsmValidRx("+QMTCONN: 0,0,0",20)){
        SER.println("MQTT CONNECTED");
        failedCount = 0;
    }

    memset(data,0,sizeof(data));  
    sprintf(data,"AT+QMTSUB=0,1,\"%s%s\",1\r\n",MQTT_TOPIC,imei);  //AT+QMTSUB=<client_idx>,<msgid>,<topic1>,<qos1>
    gsmSend(data);
    gsmValidRx("+QMTSUB: 0,1,0,1",20);   
    return 1;
}

uint8_t mqttConnect(void){
    //start:    
    // Check for mqtt connect
    gsmSend("AT+QMTCONN?\r\n");
    if(!(gsmValidRx("+QMTCONN: 0,3",20))){
        if(!(testAt())) gsmInit();    
        SER.println("MQTT NOT CONNECTED");
        //Check for MQTT Acquisition
            mqttClose();
            mqttStart();
            //goto start;
    }else{
        SER.println("MQTT ALREADY CONNECTED");
        return 1;
    }
    return 0;   
}

uint8_t mqttSub(int type){
    char data[100];
    char topic[100];    
    if(type){
        memset(topic,0,sizeof(topic));
        memset(data,0,sizeof(data));
        sprintf(topic,"%s%s",MQTT_TOPIC,imei);
        sprintf(data,"AT+CMQTTSUB=0,%d,1\r\n",(uint8_t)strlen(topic));
        gsmSend(data);
        gsmValidRx(">",20);
        gsmSend(topic);
        gsmValidRx("OK",20);
        if(strcasestr(gsm_buff,"+CMQTTSUB: 0,0")){
            SER.println("MQTT TOPIC SUBSCRIBED");
            return 1;
        }
    }
    else{
        memset(topic,0,sizeof(topic));
        memset(data,0,sizeof(data));
        sprintf(topic,"%s%s",MQTT_TOPIC,imei);
        sprintf(data,"AT+CMQTTUNSUB=0,%d,0\r\n",(uint8_t)strlen(topic));
        gsmSend(data);
        gsmValidRx(">",20);
        gsmSend(topic);
        gsmValidRx("OK",20);
        if(strcasestr(gsm_buff,"+CMQTTUNSUB: 0,0")){
            SER.println("MQTT TOPIC UN-SUBSCRIBED");
            return 1;
        }
    }
    return 0;
}

uint8_t mqttPub(const char * channel, const char * msg ){
    char data[300];
    if(mqttConnect()){
        //AT+QMTPUBEX=<client_idx>,<msgid>,<qos>,<retain>,<topic>,<length>
        //Setting of Topic
        memset(data,0,sizeof(data));
        sprintf(data,"AT+QMTPUBEX=0,%d,1,0,\"%s%s\",%d\r\n",msg_id,MQTT_TOPIC,channel,(uint8_t) strlen(msg));
        gsmSend(data);
        gsmValidRx(">",20);
        gsmSend(msg);
        gsmValidRx("+QMTPUBEX: 0",20);

        if(msg_id==0xFF) msg_id=1;
        else msg_id++;
        return 1;
    }
    SER.println("Failed to Published...");
    failedCount++;
    if(failedCount>4)checkGsm();
    return 0;    
}

uint8_t checkNetwork(void){
    do{	//Checking CS Service
		gsmSend("AT+CREG?\r");   // Transmit AT check modem
		gsmValidRx("+CREG:",4);
        vTaskDelay(500 / portTICK_PERIOD_MS);
	}while(strcasestr(gsm_buff,"+CREG: 0,2"));

	if(strcasestr(gsm_buff,"+CREG: 0,0")||strcasestr(gsm_buff,"+CREG: 0,3")||strcasestr(gsm_buff,"+CREG: 0,4")){
        SER.println("CS Network Not Registered");
        return 0;
    }
	SER.println("CS Network Registered");
    gsmRx(0);
	do{	//Checking PS Service
		gsmSend("AT+CGREG?\r");   // Transmit AT check modem
		gsmValidRx("+CGREG:",4);
        vTaskDelay(500 / portTICK_PERIOD_MS);
	}while(strcasestr(gsm_buff,"+CGREG: 0,2"));
	
	if(strcasestr(gsm_buff,"+CGREG: 0,0")||strcasestr(gsm_buff,"+CGREG: 0,3")||strcasestr(gsm_buff,"+CGREG: 0,4")){
        SER.println("PS Network Not Registered");
        return 0;
    }
	SER.println("PS Network Registered");
	gsmRx(0);
	do{	//Checking PS Service
		gsmSend("AT+CEREG?\r");   // Transmit AT check modem
		gsmValidRx("+CEREG:",4);
        vTaskDelay(500 / portTICK_PERIOD_MS);
	}while(strcasestr(gsm_buff,"+CEREG: 0,2"));
	
	if(strcasestr(gsm_buff,"+CEREG: 0,0")||strcasestr(gsm_buff,"+CEREG: 0,3")||strcasestr(gsm_buff,"+CEREG: 0,4")){
        SER.println("EPS Network Not Registered");
        return 0;
    }
	SER.println("EPS Network Registered");
    return 1;

}

uint8_t checkDataService(void){
    gsmSend("AT+CFUN=0\r");   // Transmit AT check modem
	gsmValidRx("OK",150);	
	gsmRx(0);
    gsmSend("AT+CFUN=1\r");   // Transmit AT check modem
	gsmValidRx("OK",150);	
	gsmRx(0);    
	do{	//Checking PS Service
		gsmSend("AT+CEREG?\r");   // Transmit AT check modem
		gsmValidRx("+CEREG:",4);
        vTaskDelay(1000 / portTICK_PERIOD_MS);
	}while(strcasestr(gsm_buff,"+CEREG: 0,2") || strcasestr(gsm_buff,"+CEREG: 0,0") );
	
	if(strcasestr(gsm_buff,"+CEREG: 0,0")||strcasestr(gsm_buff,"+CEREG: 0,3")||strcasestr(gsm_buff,"+CEREG: 0,4")){
        SER.println("EPS Network Not Registered");
        return 0;
    }
    gsmRx(0);
	gsmSend("AT+QIACT?\r");   
	gsmValidRx("OK",10);
    if(!(strcasestr(gsm_buff,"+QIACT:"))){
        gsmRx(0);
        gsmSend("AT+QIDEACT=1\r");
        gsmValidRx("OK",10);
        gsmRx(0);	
        gsmSend("AT+QIACT=1\r");
        gsmValidRx("OK",100);
        gsmRx(0);
        gsmSend("AT+QIACT?\r");   
        gsmValidRx("OK",10);	
        if(!(strcasestr(gsm_buff,"+QIACT:"))) return 0;
    }	
    failedCount=0;
	return 1;    
}

uint8_t checkGsm(void){
    if(failedCount>4 && failedCount<10 ){
        gsmPower(2);
        gsmInit();
        if(failedCount)failedCount=10;
        else return 1;
    }
    if(failedCount>15)esp_restart();
    return 0;
}


uint8_t gsmInit(void) {
    SER.printf("(gsmInit)-Job is Running on Core :%d\n", xPortGetCoreID());
    if(!(testAt())) {
        SER.println("GSM Modem Not Responding");
        return 1;
    }

    SER.println("GSM Modem Responded");
    gsmSend("AT+CPIN?\r");   // Transmit AT check modem
	if(!(gsmValidRx("+CPIN: READY",50))){
        SER.println("SIM Not Detected, Please Check");
        return 2;
    } 
    SER.println("SIM Detected");

    gsmSend("AT+CSQ\r");   // Transmit AT check modem
	gsmValidRx("+CSQ:",4);
	
	gsmSend("AT+CPMS=\"SM\",\"SM\",\"SM\"\r");
    gsmValidRx("OK",10);
	gsmSend("AT+CPBS=\"SM\"\r"); 
    gsmValidRx("OK",10);
	gsmSend("AT+CMGF=1\r");
    gsmValidRx("OK",10);
    gsmSend("AT+CLIP=1\r");
    gsmValidRx("OK",10);
    gsmSend("AT+CTZU=3\r");
    gsmValidRx("OK",10);
    if(!(checkNetwork())) return 3;
    
/*
    gsmSend("AT+QHTTPCFG=\"contextid\",1\r");   // Transmit AT check modem
	gsmValidRx("OK",5);
	gsmRx(0);
	gsmSend("AT+QHTTPCFG=\"responseheader\",0\r");   // Transmit AT check modem
	gsmValidRx("OK",5);
    gsmRx(0);
*/	
	
    //_delay_ms(2000);	
	if(!(setApn())) return 5;	//Check Internet Status and set APN	
	if(!(getImei())) return 6;	//extracting IMEI
    if(!(checkDataService())) return 4;   

	failedCount=0;	
    syncTime();
    //check_sms();
    mqttClose();
    mqttStart();
    mqttConnect();
    //mqttSub(1);   
    SETBIT(tpmsStatus,gsm);

        
	return 0;
}




