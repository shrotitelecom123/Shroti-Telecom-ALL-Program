#define PRODUCT "TPMS"
#define SER Serial

//MQTT Server

#define MQTT_SERVER     "mqtt.shrotigroup.in"
#define MQTT_PORT       1883
#define MQTT_TOPIC      "STPL/TPMS/"
//#define MQTT_KEEP_ALIVE 300
//#define QOS             1
//#define HOOTERONCOVEROPEN 1
#define INPUT_CHANNEL 16

/*
#define TPMS_PORT_MASK 0xFFFF
#define TPMS_REPT_BLK_MASK 0xFFFF
#define HOOTER_MASK 0xFFFF
#define IAMS_PORT_MASK 0xFFFF
#define UPDATE_INTERVAL  1
#define BLOCK_INTERVAL  10
#define HOOTER_INTERVAL  5
*/

extern uint16_t TPMS_PORT_MASK ;
extern uint16_t TPMS_REPT_BLK_MASK ;
extern uint16_t HOOTER_MASK ;
extern uint16_t IAMS_PORT_MASK ;
extern uint8_t UPDATE_INTERVAL ;
extern uint8_t BLOCK_INTERVAL;
extern uint8_t HOOTER_INTERVAL;

#define RX_BUF_SIZE  256
#define MQTT_RX_BUF_SIZE 128
#define MQTT_TX_BUF_SIZE 128
#define MQTT_TX_CH_SIZE 20


#define SETBIT(ADDRESS,VALUE)   (ADDRESS |= (1<<VALUE))
#define CLEARBIT(ADDRESS,VALUE) (ADDRESS &= ~(1<<VALUE))
#define FLIPBIT(ADDRESS,VALUE)  (ADDRESS ^= (1<<VALUE))
#define CHECKBIT(ADDRESS,VALUE) (ADDRESS & (1<<VALUE))

// IAMS Alarm bit index
#define alarmEb			    0							
#define alarmDg			    1					
#define alarmFire   		2					
#define alarmMotion	    	3					
#define alarmDoor		    4					
#define alarmCover	    	5					
#define alarmHrt		    6					
#define alarmBtlv		    7					

#define alarmInput		    8
#define alarmBattCritcal	9
#define ebDgInterchange		10
#define dgFailedToStart		11
#define hooterStatus		12
#define paramUdated		    15

extern uint16_t tpmsStatus;

#define gsm 			    0							
#define wifi			    1					
#define rs485          		2					
#define i2c     	    	3					
#define spi     		    4					
#define ethernet	    	5					
#define fileStatus		    6					
#define alarmChanged	    7
#define timeSync    	    8





//UART.CPP
void uartInit(void);
int gsmSend(const char *data);
void gsmRx(int cumulative);
uint8_t gsmValidRx(const char * parameter, int duration);
extern char gsm_buff[]; 
void gsmPower(uint8_t status); 


//TPMS.CPP
void clearBuff(char * buff);
void delay_ms(int value);
void tpmsInit(void);
void sysReset(void);
//void l74hc595_setregallon();
//void l74hc595_setregalloff();
void l74hc595_setreg(uint16_t regindex, uint8_t val);
void l74hc595_setchipbyte(uint8_t chipindex, uint8_t val);
void DBUG(String data);
extern SemaphoreHandle_t xSemaMqqtTxBuff;

#define l74hc595_setregon(regindex) l74hc595_setreg(regindex, 1);
#define l74hc595_setregoff(regindex) l74hc595_setreg(regindex, 0);
#define HOOTER_ON l74hc595_setregon(12);
#define HOOTER_OFF l74hc595_setregon(12);
#define GPIO1_ON l74hc595_setregon(0);
#define GPIO1_OFF l74hc595_setregon(0);
#define GPIO2_ON l74hc595_setregon(1);
#define GPIO2_OFF l74hc595_setregon(1);
#define GPIO3_ON l74hc595_setregon(2);
#define GPIO3_OFF l74hc595_setregon(2);
#define GPIO4_ON l74hc595_setregon(3);
#define GPIO4_OFF l74hc595_setregon(3);
#define RST_4G_ON l74hc595_setregon(9);
#define RST_4G_OFF l74hc595_setregon(9);
#define PWR_4G_ON l74hc595_setregon(10);
#define PWR_4G_OFF l74hc595_setregon(10);
#define RS485_EN_ON l74hc595_setregon(11);
#define RS485_EN_OFF l74hc595_setregon(11);
#define RSTN_ON l74hc595_setregon(13);
#define RSTN_OFF l74hc595_setregon(13);


typedef struct {
    uint8_t min;           /*!<ADC pin */
    uint16_t alarm;       /*!<ADC channel */
} alarm_data_t;

//GSM.CPP
extern uint8_t failedCount;
extern char imei[];
uint8_t gsmInit(void);
uint8_t checkGsm(void);
u_int32_t tCount (const char * level);
uint8_t mqttPub(const char * channel, const char * msg );
void corrTime(void);
void modemReset(void);


//SMS.CPP
void check_sms(void);



//WIFI.CPP
void wifiInit();
void println(char * msg);
void print(char * msg);


//FILE.CPP

void listDir(const char * dirname, uint8_t levels);
void createDir(const char * path);
void removeDir(const char * path);
String readFile(const char * path);
String readFileLine(const char * path, int line);
void writeFile(const char * path, const char * message);
uint8_t appendFile(const char * path, const char * message);
void renameFile(const char * path1, const char * path2);
void deleteFile(const char * path);
void testFileIO(const char * path);
void fileInit();



//MASTER.CPP

void mobusInit(void);


//PARAM.CPP

void readParam(void);
void saveParam(void);







